<?php

if(isset($_SESSION['idaluno']) && !empty($_SESSION[idaluno])){
    require_once'suario.class.php';
}else{
    header("Location:index.php");
}
?>