<?php


class Usuario{
    public function login($idaluno,$senha){
        global $pdo;
        
        $sql="SELECT * FROM aluno WHERE idaluno=:idaluno AND senha=:senha";
        $sql=$pdo->prepare($sql);
        $sql->bindValue("idaluno",$idaluno);
         $sql->bindValue("senha",sha1($senha));
        $sql->execute();
        
        if($sql->rowCount>0){
            $dado=$sql->fetch();
            $_SESSION['idaluno']=$dado['idaluno'];
            return true;
        }else{
            return false;
        }
    }
    public function logged($id){
        
        global $pdo;
        
        $array = array();
         $sql="SELECT * FROM aluno WHERE idaluno=:id;"
         
    }




?>