export const disciplinas = [
  {
    disciplina: "Lógica de Programação",
    professor: "João Pedro Ribeiro Batista",
    targetModal: "modalDisciplina1",
  },
  {
    disciplina: "Fundamentos de Tecnologia da Informação",
    professor: "Ariele Nogueira Chagas",
    targetModal: "modalDisciplina2",
  },
  {
    disciplina: "Comunicação Oral e Escrita",
    professor: "Eusébio Garrau Rabelo",
    targetModal: "modalDisciplina3",
  },
  {
    disciplina: "Fundamentos de Web Design",
    professor: "Danilho Bonilha Castanheira",
    targetModal: "modalDisciplina4",
  },
  {
    disciplina: "Informática Aplicada",
    professor: "Klara Sequeira Bensaúde",
    targetModal: "modalDisciplina5",
  },
  {
    disciplina: "Inovação e Empreendedorismo",
    professor: "Manha Moita Junqueira",
    targetModal: "modalDisciplina6",
  },
  {
    disciplina: "Inovação e Empreendedorismo",
    professor: "Eshal Tedim Teles",
    targetModal: "modalDisciplina6",
  },
  {
    disciplina: "Programação WEB",
    professor: "Sarai Ginjeira Marins",
    targetModal: "modalDisciplina7",
  },
  {
    disciplina: "Desenvolvimento de Sistemas I",
    professor: "Ashley Cortês Dâmaso",
    targetModal: "modalDisciplina8",
  },
  {
    disciplina: "Interface Humano Máquina",
    professor: "Maryam Falcão Cavaco",
    targetModal: "modalDisciplina9",
  },
  {
    disciplina: "Modelagem de Sistemas",
    professor: "Pandora Milhães Veríssimo",
    targetModal: "modalDisciplina10",
  },
  {
    disciplina: "Metolodogia da Pesquisa",
    professor: "Nikolas Quintal Caldas",
    targetModal: "modalDisciplina11",
  },
  {
    disciplina: "Gestão de Projetos",
    professor: "Ariane Goulart Quintais",
    targetModal: "modalDisciplina12",
  },
  {
    disciplina: "Desenvolvimento de Sistemas para Dispositivos Móveis",
    professor: "Cristina Reis Rios",
    targetModal: "modalDisciplina13",
  },
  {
    disciplina: "Desenvolvimento de Sistemas II",
    professor: "Stela Cabreira Duarte",
    targetModal: "modalDisciplina14",
  },
  {
    disciplina: "Banco de Dados",
    professor: "Israel Lira Lobato",
    targetModal: "modalDisciplina15",
  },
  {
    disciplina: "Testes de Sistemas",
    professor: "Omar Vilanova Camilo",
    targetModal: "modalDisciplina16",
  },
  {
    disciplina: "Trabalho de Conclusão de Curso",
    professor: "Dérick Souto Maior Caldas",
    targetModal: "modalDisciplina17",
  },
];
