export const disciplinas = [
  {
    disciplina: "Lógica de Programação",
    targetModal: "modalDisciplina1",
  },
  {
    disciplina: "Fundamentos de Tecnologia da Informação",
    targetModal: "modalDisciplina2",
  },
  {
    disciplina: "Comunicação Oral e Escrita",
    targetModal: "modalDisciplina3",
  },
  {
    disciplina: "Fundamentos de Web Design",
    targetModal: "modalDisciplina4",
  },
  {
    disciplina: "Informática Aplicada",
    targetModal: "modalDisciplina5",
  },
  {
    disciplina: "Inovação e Empreendedorismo",
    targetModal: "modalDisciplina6",
  },
  {
    disciplina: "Inovação e Empreendedorismo",
    targetModal: "modalDisciplina6",
  },
  {
    disciplina: "Programação WEB",
    targetModal: "modalDisciplina7",
  },
  {
    disciplina: "Desenvolvimento de Sistemas I",
    targetModal: "modalDisciplina8",
  },
  {
    disciplina: "Interface Humano Máquina",
    targetModal: "modalDisciplina9",
  },
  {
    disciplina: "Modelagem de Sistemas",
    targetModal: "modalDisciplina10",
  },
  {
    disciplina: "Metolodogia da Pesquisa",
    targetModal: "modalDisciplina11",
  },
  {
    disciplina: "Gestão de Projetos",
    targetModal: "modalDisciplina12",
  },
  {
    disciplina: "Desenvolvimento de Sistemas para Dispositivos Móveis",
    targetModal: "modalDisciplina13",
  },
  {
    disciplina: "Desenvolvimento de Sistemas II",
    targetModal: "modalDisciplina14",
  },
  {
    disciplina: "Banco de Dados",
    targetModal: "modalDisciplina15",
  },
  {
    disciplina: "Testes de Sistemas",
    targetModal: "modalDisciplina16",
  },
  {
    disciplina: "Trabalho de Conclusão de Curso",
    targetModal: "modalDisciplina17",
  },
];
